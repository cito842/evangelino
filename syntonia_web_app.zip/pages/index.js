import { useState } from 'react';

export default function Home() {
  const [messages, setMessages] = useState([
    { role: 'ai', text: 'Benvenuto in Syntonia. Prenditi un momento per ascoltarti davvero…' }
  ]);
  const [input, setInput] = useState('');
  const [count, setCount] = useState(1);

  const sendMessage = () => {
    if (!input.trim()) return;
    const newMessages = [...messages, { role: 'user', text: input }];
    const reply = generateStrategicReply(input);
    setMessages([...newMessages, { role: 'ai', text: reply }]);
    setInput('');
    setCount(count + 1);
  };

  const generateStrategicReply = (input) => {
    const responses = [
      "Se potessi guardare questo problema da fuori, cosa vedresti accadere?",
      "Cosa succederebbe se iniziassi a fare il contrario di ciò che fai ora?",
      "Immagina una porta che si apre. Cosa trovi dall’altra parte?",
      "Qual è il più piccolo cambiamento possibile che potresti fare subito?"
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  return (
    <main style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h1 style={{ fontSize: 24 }}>Syntonia – Terapia Sistemica</h1>
      <div style={{ border: '1px solid #ccc', padding: 10, height: 200, overflowY: 'scroll' }}>
        {messages.map((msg, i) => (
          <div key={i} style={{ textAlign: msg.role === 'user' ? 'right' : 'left' }}>{msg.text}</div>
        ))}
      </div>
      <div style={{ marginTop: 10 }}>
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Scrivi qui…" />
        <button onClick={sendMessage}>Invia</button>
      </div>
      <p style={{ fontSize: 12 }}>Sedute: {count} / 4</p>
    </main>
  );
}