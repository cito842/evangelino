# Syntonia Web App

App di psicoterapia sistemico-strategica con AI.